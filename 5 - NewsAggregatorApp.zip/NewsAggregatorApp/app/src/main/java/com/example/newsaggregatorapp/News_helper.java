package com.example.newsaggregatorapp;

import java.util.List;

public class News_helper {
    private String status;
    private List<Source> sources;

    public News_helper(String status, List<Source> sources) {
        this.status = status;
        this.sources = sources;
    }

    public List<Source> getSources() {
        return sources;
    }
}
