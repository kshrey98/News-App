package com.example.newsaggregatorapp;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.viewpager2.widget.ViewPager2;

import android.app.Activity;
import android.content.res.Configuration;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private Menu menu;
    News_helper news;
    private static List<Articles> ArticleDetails = new ArrayList<>();
    NewsAdapter articlesAdapter;
    private ArrayAdapter<Source> arrAdapter;

    private ActionBarDrawerToggle drawerToggle;
    List<Source> sourceList;
    List<Source> list;
    private ViewPager2 viewPager2;
    private DrawerLayout drawer;
    private ListView drawerList;

    TextView menuItem;

    HashMap<String, String> color;
    private static HashMap<String, String> hashMap = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        String app_tile = "News Gateway";
        setTitle(app_tile);

        viewPager2 = findViewById(R.id.viewPager2_id);
        drawer = findViewById(R.id.drawer);
        drawerList = findViewById(R.id.drawer_layout);

        boolean isNetworkConnected = checkNetworkConnection();
        if(isNetworkConnected){
            getNewsData();
        }
        else {
            Toast.makeText(this,"No Internet Connection",Toast.LENGTH_LONG).show();
        }
        drawerList.setOnItemClickListener(
                (parent, view, position, id) -> selectItem(position)
        );

        drawerToggle = new ActionBarDrawerToggle(this,
                drawer, R.string.drawer_open,R.string.drawer_close);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setHomeButtonEnabled(true);
        }
    }

    public static Boolean isNetworkConnected(Activity activity){
        ConnectivityManager connectivityManager = activity.getSystemService(ConnectivityManager.class);
        NetworkInfo network = connectivityManager.getActiveNetworkInfo();
        if(network != null && network.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        this.menu = menu;
        return true;
    }

    private void getNewsData() {
        news = API_helper.getAPIData(this);
        //Log.e("NEWS", String.valueOf((news.getSources().size())));
    }

    @Override
    protected void onPostCreate(Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        drawerToggle.syncState();
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        drawerToggle.onConfigurationChanged(newConfig);
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (drawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        if(item.getTitle().equals("All")){
            updateDrawerItems(sourceList, item.getTitle().toString());
        }
        else if(item.getTitle() != null){
            List<Source> updatedList =  API_helper.updateDrawerLayoutData(item.getTitle().toString());
            String str = item.getTitle().toString();
            updateDrawerItems(updatedList, str);
        }
        else {

        }
        return super.onOptionsItemSelected(item);
    }

    private void updateDrawerItems(List<Source> updateDrawerItems, String title) {
        list = updateDrawerItems;
        arrAdapter = new ArrayAdapter<Source>(this, android.R.layout.simple_list_item_1, updateDrawerItems){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                Source newsSource = updateDrawerItems.get(position);
                View view = super.getView(position, convertView, parent);
                menuItem = (TextView) view.findViewById(android.R.id.text1);
                menuItem.setText(newsSource.getName());
                if(title.equals("All")){
                    int allListLength = updateDrawerItems.size();
                    String title = "News Gateway";
                    setTitle(title + " " + "(" + allListLength + ")" );
                    menuItem.setTextColor(Color.parseColor(color.get(newsSource.getCategory())));
                }
                else {
                    int len = updateDrawerItems.size();
                    setTitle(updateDrawerItems.get(0).getCategory() + " (" + len + ")");
                }
                menuItem.setTextColor(Color.parseColor(color.get(newsSource.getCategory())));
                return view;
            }
        };
        drawerList.setAdapter(arrAdapter);
    }

    private void selectItem(int position) {
        String setSourceTitle = list.get(position).getName();
        setTitle(setSourceTitle);
        ArticleDetails = API_helper.getArticles(list.get(position).getId(), this);
        Log.e("Main activity", String.valueOf(ArticleDetails));
        viewPager2.setCurrentItem(position);
        drawer.setBackgroundResource(0);
        viewPager2.setBackground(null);
        drawer.closeDrawer(drawerList);
    }

    private boolean checkNetworkConnection() {
        if(isNetworkConnected(this)){
            return true;
        }
        return false;
    }

    public void updateData(News_helper news) {
        this.news = news;
        sourceList = news.getSources();
        list = sourceList;

        arrAdapter = new ArrayAdapter<Source>(this, android.R.layout.simple_list_item_1, this.sourceList){
            @NonNull
            @Override
            public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
                Source source = sourceList.get(position);

                View view = super.getView(position, convertView, parent);
                menuItem = (TextView) view.findViewById(android.R.id.text1);

                menuItem.setText(source.getName());

                int len = sourceList.size();
                String title = "News Gateway ";
                setTitle(title + "(" + len + ")");

                menuItem.setTextColor(Color.parseColor(color.get(source.getCategory())));
                return view;
            }
        };
        drawerList.setAdapter(arrAdapter);
    }

    public void updateMenuItem(HashSet<String> dynamicMenu) {
        color = sourceColors(dynamicMenu);
        for (String menu: dynamicMenu) {
            if(!menu.equals("All")){
                SpannableString sstr = new SpannableString(menu);
                sstr.setSpan(new ForegroundColorSpan(Color.parseColor(color.get(menu))), 0, sstr.length(), 0);
                this.menu.add(sstr);
            }
            else {
                this.menu.add(menu);
            }
        }
    }

    public void updateViewPager(List<Articles> ArticleDetails) {
        articlesAdapter = new NewsAdapter(this, ArticleDetails);
        articlesAdapter.notifyDataSetChanged();
        viewPager2.setAdapter(articlesAdapter);
    }

    public static HashMap<String, String> sourceColors(HashSet<String> dynamicMenu){

        List<String> list = new ArrayList<String>();


        list.add("#EB5F9EA0");//RED
        list.add("#DDA52A2A");//YELLOW
        list.add("#DC8A2BE2");//ORANGE
        list.add("#F2008B8B");//PINK
        list.add("#DC6495ED");//LIGHT PINK
        list.add("#EBDC143C"); // LIGHT YELLOW
        list.add("#D8FF7F50"); /// LIGHT FLOE
        list.add("#E97FFF00");//ROSE
        list.add("#EBDEB887");//PALE YELO
        list.add("#F5D2691E"); // SOME YELLOW
        list.add("#EB5F9EA0"); //PINK

        int index = 0;
        for(String str : dynamicMenu){
            hashMap.put(str, list.get(index));
            index++;
        }
        return hashMap;
    }
}